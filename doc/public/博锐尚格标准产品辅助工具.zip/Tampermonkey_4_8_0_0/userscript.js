'use strict';Registry.require(["helper"],function(){var a=Registry.get("helper").getUrlArgs(!0);a.id&&(window.location.href=rea.extension.getURL("options.html")+"#nav="+a.id+"+editor")});
